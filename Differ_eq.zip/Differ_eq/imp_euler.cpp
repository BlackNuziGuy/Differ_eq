#include "imp_euler.h"

Imp_Euler::Imp_Euler()
{

}

//Graphs
