#ifndef KUNKKA_H
#define KUNKKA_H


class Kunkka
{
public:
    Kunkka();
};

#endif // KUNKKA_H
