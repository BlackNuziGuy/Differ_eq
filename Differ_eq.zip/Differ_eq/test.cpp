#include "test.h"
#include "ui_test.h"

TEST::TEST(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::TEST)
{
    ui->setupUi(this);
}

TEST::~TEST()
{
    delete ui;
}
