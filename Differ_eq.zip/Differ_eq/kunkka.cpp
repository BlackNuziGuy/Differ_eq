#include "kunkka.h"

Kunkka::Kunkka()
{

}

