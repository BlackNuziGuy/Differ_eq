#ifndef IMP_EULER_H
#define IMP_EULER_H


class Imp_Euler
{
public:
    Imp_Euler();
};

#endif // IMP_EULER_H
