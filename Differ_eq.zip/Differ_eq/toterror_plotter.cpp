#include "toterror_plotter.h"

TotError_Plotter::TotError_Plotter(QCustomPlot *gr,Main_Plotter *pl) : Plotter(gr){



}

void TotError_Plotter::Caculate_all(double x0, double y0, double X, int N){

}

void TotError_Plotter::Zoom(double, double){

}

